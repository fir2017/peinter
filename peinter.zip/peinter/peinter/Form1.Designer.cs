﻿namespace peinter
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.editToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.viewToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.formatToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.fillToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.shapedToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.basicShape2DToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.dotToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.linesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.lineToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.segmentToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.shapesNGone2DToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.triangleToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.nGonToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.squareToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pentagonToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.sexagonToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.heptagonToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.octogonToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.decagonToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.dodecagonToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.starToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.startNCornersToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.poligoneToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.poligonToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pathToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.square2DToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.squareToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.patrulaterToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.paralelogramToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.rombToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.trapezToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.dreptunghiToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.circleToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cercToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.elipsaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.arcToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ovalToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ovoidToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.circleToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.graficToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pieToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.chartToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.histogramToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.analiticGeometricToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.formulasToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.trigonometricToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.sinToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tanToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cotToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.secToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cosecToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.aritmeticToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.matematicToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.logToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.lnToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.expToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.geometricToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.analiticToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.optionsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.windowToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.helpToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.White;
            this.pictureBox1.Location = new System.Drawing.Point(1, 33);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(553, 369);
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Paint += new System.Windows.Forms.PaintEventHandler(this.pictureBox1_Paint);
            this.pictureBox1.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pictureBox1_MouseDown);
            this.pictureBox1.MouseMove += new System.Windows.Forms.MouseEventHandler(this.pictureBox1_MouseMove);
            this.pictureBox1.MouseUp += new System.Windows.Forms.MouseEventHandler(this.pictureBox1_MouseUp);
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem,
            this.editToolStripMenuItem,
            this.viewToolStripMenuItem,
            this.formatToolStripMenuItem,
            this.shapedToolStripMenuItem,
            this.formulasToolStripMenuItem,
            this.toolsToolStripMenuItem,
            this.optionsToolStripMenuItem,
            this.windowToolStripMenuItem,
            this.helpToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(556, 24);
            this.menuStrip1.TabIndex = 1;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(37, 20);
            this.fileToolStripMenuItem.Text = "File";
            // 
            // editToolStripMenuItem
            // 
            this.editToolStripMenuItem.Name = "editToolStripMenuItem";
            this.editToolStripMenuItem.Size = new System.Drawing.Size(39, 20);
            this.editToolStripMenuItem.Text = "Edit";
            // 
            // viewToolStripMenuItem
            // 
            this.viewToolStripMenuItem.Name = "viewToolStripMenuItem";
            this.viewToolStripMenuItem.Size = new System.Drawing.Size(44, 20);
            this.viewToolStripMenuItem.Text = "View";
            // 
            // formatToolStripMenuItem
            // 
            this.formatToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fillToolStripMenuItem});
            this.formatToolStripMenuItem.Name = "formatToolStripMenuItem";
            this.formatToolStripMenuItem.Size = new System.Drawing.Size(57, 20);
            this.formatToolStripMenuItem.Text = "Format";
            // 
            // fillToolStripMenuItem
            // 
            this.fillToolStripMenuItem.Name = "fillToolStripMenuItem";
            this.fillToolStripMenuItem.Size = new System.Drawing.Size(89, 22);
            this.fillToolStripMenuItem.Text = "Fill";
            // 
            // shapedToolStripMenuItem
            // 
            this.shapedToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.basicShape2DToolStripMenuItem,
            this.linesToolStripMenuItem,
            this.shapesNGone2DToolStripMenuItem,
            this.poligoneToolStripMenuItem,
            this.square2DToolStripMenuItem,
            this.circleToolStripMenuItem,
            this.graficToolStripMenuItem,
            this.analiticGeometricToolStripMenuItem});
            this.shapedToolStripMenuItem.Name = "shapedToolStripMenuItem";
            this.shapedToolStripMenuItem.Size = new System.Drawing.Size(65, 20);
            this.shapedToolStripMenuItem.Text = "Shape2D";
            // 
            // basicShape2DToolStripMenuItem
            // 
            this.basicShape2DToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.dotToolStripMenuItem});
            this.basicShape2DToolStripMenuItem.Name = "basicShape2DToolStripMenuItem";
            this.basicShape2DToolStripMenuItem.Size = new System.Drawing.Size(169, 22);
            this.basicShape2DToolStripMenuItem.Text = "BasicShape2D";
            // 
            // dotToolStripMenuItem
            // 
            this.dotToolStripMenuItem.Name = "dotToolStripMenuItem";
            this.dotToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.dotToolStripMenuItem.Text = "Dot";
            this.dotToolStripMenuItem.Click += new System.EventHandler(this.dotToolStripMenuItem_Click);
            // 
            // linesToolStripMenuItem
            // 
            this.linesToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.lineToolStripMenuItem,
            this.segmentToolStripMenuItem});
            this.linesToolStripMenuItem.Name = "linesToolStripMenuItem";
            this.linesToolStripMenuItem.Size = new System.Drawing.Size(169, 22);
            this.linesToolStripMenuItem.Text = "Lines2D";
            // 
            // lineToolStripMenuItem
            // 
            this.lineToolStripMenuItem.Name = "lineToolStripMenuItem";
            this.lineToolStripMenuItem.Size = new System.Drawing.Size(121, 22);
            this.lineToolStripMenuItem.Text = "Line";
            this.lineToolStripMenuItem.Click += new System.EventHandler(this.lineToolStripMenuItem_Click);
            // 
            // segmentToolStripMenuItem
            // 
            this.segmentToolStripMenuItem.Name = "segmentToolStripMenuItem";
            this.segmentToolStripMenuItem.Size = new System.Drawing.Size(121, 22);
            this.segmentToolStripMenuItem.Text = "Segment";
            // 
            // shapesNGone2DToolStripMenuItem
            // 
            this.shapesNGone2DToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.triangleToolStripMenuItem,
            this.nGonToolStripMenuItem,
            this.squareToolStripMenuItem,
            this.pentagonToolStripMenuItem,
            this.sexagonToolStripMenuItem,
            this.heptagonToolStripMenuItem,
            this.octogonToolStripMenuItem,
            this.decagonToolStripMenuItem,
            this.dodecagonToolStripMenuItem,
            this.starToolStripMenuItem,
            this.startNCornersToolStripMenuItem});
            this.shapesNGone2DToolStripMenuItem.Name = "shapesNGone2DToolStripMenuItem";
            this.shapesNGone2DToolStripMenuItem.Size = new System.Drawing.Size(169, 22);
            this.shapesNGone2DToolStripMenuItem.Text = "NGone2D";
            // 
            // triangleToolStripMenuItem
            // 
            this.triangleToolStripMenuItem.Name = "triangleToolStripMenuItem";
            this.triangleToolStripMenuItem.Size = new System.Drawing.Size(148, 22);
            this.triangleToolStripMenuItem.Text = "Triangle";
            // 
            // nGonToolStripMenuItem
            // 
            this.nGonToolStripMenuItem.Name = "nGonToolStripMenuItem";
            this.nGonToolStripMenuItem.Size = new System.Drawing.Size(148, 22);
            this.nGonToolStripMenuItem.Text = "NGon";
            // 
            // squareToolStripMenuItem
            // 
            this.squareToolStripMenuItem.Name = "squareToolStripMenuItem";
            this.squareToolStripMenuItem.Size = new System.Drawing.Size(148, 22);
            this.squareToolStripMenuItem.Text = "Square";
            // 
            // pentagonToolStripMenuItem
            // 
            this.pentagonToolStripMenuItem.Name = "pentagonToolStripMenuItem";
            this.pentagonToolStripMenuItem.Size = new System.Drawing.Size(148, 22);
            this.pentagonToolStripMenuItem.Text = "Pentagon";
            // 
            // sexagonToolStripMenuItem
            // 
            this.sexagonToolStripMenuItem.Name = "sexagonToolStripMenuItem";
            this.sexagonToolStripMenuItem.Size = new System.Drawing.Size(148, 22);
            this.sexagonToolStripMenuItem.Text = "Sexagon";
            // 
            // heptagonToolStripMenuItem
            // 
            this.heptagonToolStripMenuItem.Name = "heptagonToolStripMenuItem";
            this.heptagonToolStripMenuItem.Size = new System.Drawing.Size(148, 22);
            this.heptagonToolStripMenuItem.Text = "Heptagon";
            // 
            // octogonToolStripMenuItem
            // 
            this.octogonToolStripMenuItem.Name = "octogonToolStripMenuItem";
            this.octogonToolStripMenuItem.Size = new System.Drawing.Size(148, 22);
            this.octogonToolStripMenuItem.Text = "Octogon";
            // 
            // decagonToolStripMenuItem
            // 
            this.decagonToolStripMenuItem.Name = "decagonToolStripMenuItem";
            this.decagonToolStripMenuItem.Size = new System.Drawing.Size(148, 22);
            this.decagonToolStripMenuItem.Text = "Decagon";
            // 
            // dodecagonToolStripMenuItem
            // 
            this.dodecagonToolStripMenuItem.Name = "dodecagonToolStripMenuItem";
            this.dodecagonToolStripMenuItem.Size = new System.Drawing.Size(148, 22);
            this.dodecagonToolStripMenuItem.Text = "Dodecagon";
            // 
            // starToolStripMenuItem
            // 
            this.starToolStripMenuItem.Name = "starToolStripMenuItem";
            this.starToolStripMenuItem.Size = new System.Drawing.Size(148, 22);
            this.starToolStripMenuItem.Text = "Star";
            // 
            // startNCornersToolStripMenuItem
            // 
            this.startNCornersToolStripMenuItem.Name = "startNCornersToolStripMenuItem";
            this.startNCornersToolStripMenuItem.Size = new System.Drawing.Size(148, 22);
            this.startNCornersToolStripMenuItem.Text = "StartNCorners";
            // 
            // poligoneToolStripMenuItem
            // 
            this.poligoneToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.poligonToolStripMenuItem,
            this.pathToolStripMenuItem});
            this.poligoneToolStripMenuItem.Name = "poligoneToolStripMenuItem";
            this.poligoneToolStripMenuItem.Size = new System.Drawing.Size(169, 22);
            this.poligoneToolStripMenuItem.Text = "Poligone";
            // 
            // poligonToolStripMenuItem
            // 
            this.poligonToolStripMenuItem.Name = "poligonToolStripMenuItem";
            this.poligonToolStripMenuItem.Size = new System.Drawing.Size(115, 22);
            this.poligonToolStripMenuItem.Text = "Poligon";
            // 
            // pathToolStripMenuItem
            // 
            this.pathToolStripMenuItem.Name = "pathToolStripMenuItem";
            this.pathToolStripMenuItem.Size = new System.Drawing.Size(115, 22);
            this.pathToolStripMenuItem.Text = "Path";
            // 
            // square2DToolStripMenuItem
            // 
            this.square2DToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.squareToolStripMenuItem1,
            this.patrulaterToolStripMenuItem,
            this.paralelogramToolStripMenuItem,
            this.rombToolStripMenuItem,
            this.trapezToolStripMenuItem,
            this.dreptunghiToolStripMenuItem});
            this.square2DToolStripMenuItem.Name = "square2DToolStripMenuItem";
            this.square2DToolStripMenuItem.Size = new System.Drawing.Size(169, 22);
            this.square2DToolStripMenuItem.Text = "Square2D";
            // 
            // squareToolStripMenuItem1
            // 
            this.squareToolStripMenuItem1.Name = "squareToolStripMenuItem1";
            this.squareToolStripMenuItem1.Size = new System.Drawing.Size(144, 22);
            this.squareToolStripMenuItem1.Text = "Square";
            this.squareToolStripMenuItem1.Click += new System.EventHandler(this.squareToolStripMenuItem1_Click);
            // 
            // patrulaterToolStripMenuItem
            // 
            this.patrulaterToolStripMenuItem.Name = "patrulaterToolStripMenuItem";
            this.patrulaterToolStripMenuItem.Size = new System.Drawing.Size(144, 22);
            this.patrulaterToolStripMenuItem.Text = "Patrulater";
            // 
            // paralelogramToolStripMenuItem
            // 
            this.paralelogramToolStripMenuItem.Name = "paralelogramToolStripMenuItem";
            this.paralelogramToolStripMenuItem.Size = new System.Drawing.Size(144, 22);
            this.paralelogramToolStripMenuItem.Text = "Paralelogram";
            // 
            // rombToolStripMenuItem
            // 
            this.rombToolStripMenuItem.Name = "rombToolStripMenuItem";
            this.rombToolStripMenuItem.Size = new System.Drawing.Size(144, 22);
            this.rombToolStripMenuItem.Text = "Romb";
            // 
            // trapezToolStripMenuItem
            // 
            this.trapezToolStripMenuItem.Name = "trapezToolStripMenuItem";
            this.trapezToolStripMenuItem.Size = new System.Drawing.Size(144, 22);
            this.trapezToolStripMenuItem.Text = "Trapez";
            // 
            // dreptunghiToolStripMenuItem
            // 
            this.dreptunghiToolStripMenuItem.Name = "dreptunghiToolStripMenuItem";
            this.dreptunghiToolStripMenuItem.Size = new System.Drawing.Size(144, 22);
            this.dreptunghiToolStripMenuItem.Text = "Dreptunghi";
            this.dreptunghiToolStripMenuItem.Click += new System.EventHandler(this.dreptunghiToolStripMenuItem_Click);
            // 
            // circleToolStripMenuItem
            // 
            this.circleToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.cercToolStripMenuItem,
            this.elipsaToolStripMenuItem,
            this.arcToolStripMenuItem,
            this.ovalToolStripMenuItem,
            this.ovoidToolStripMenuItem,
            this.circleToolStripMenuItem1});
            this.circleToolStripMenuItem.Name = "circleToolStripMenuItem";
            this.circleToolStripMenuItem.Size = new System.Drawing.Size(169, 22);
            this.circleToolStripMenuItem.Text = "Circle";
            // 
            // cercToolStripMenuItem
            // 
            this.cercToolStripMenuItem.Name = "cercToolStripMenuItem";
            this.cercToolStripMenuItem.Size = new System.Drawing.Size(106, 22);
            this.cercToolStripMenuItem.Text = "Cerc";
            this.cercToolStripMenuItem.Click += new System.EventHandler(this.cercToolStripMenuItem_Click);
            // 
            // elipsaToolStripMenuItem
            // 
            this.elipsaToolStripMenuItem.Name = "elipsaToolStripMenuItem";
            this.elipsaToolStripMenuItem.Size = new System.Drawing.Size(106, 22);
            this.elipsaToolStripMenuItem.Text = "Elipsa";
            this.elipsaToolStripMenuItem.Click += new System.EventHandler(this.elipsaToolStripMenuItem_Click);
            // 
            // arcToolStripMenuItem
            // 
            this.arcToolStripMenuItem.Name = "arcToolStripMenuItem";
            this.arcToolStripMenuItem.Size = new System.Drawing.Size(106, 22);
            this.arcToolStripMenuItem.Text = "Arc";
            this.arcToolStripMenuItem.Click += new System.EventHandler(this.arcToolStripMenuItem_Click);
            // 
            // ovalToolStripMenuItem
            // 
            this.ovalToolStripMenuItem.Name = "ovalToolStripMenuItem";
            this.ovalToolStripMenuItem.Size = new System.Drawing.Size(106, 22);
            this.ovalToolStripMenuItem.Text = "Oval";
            // 
            // ovoidToolStripMenuItem
            // 
            this.ovoidToolStripMenuItem.Name = "ovoidToolStripMenuItem";
            this.ovoidToolStripMenuItem.Size = new System.Drawing.Size(106, 22);
            this.ovoidToolStripMenuItem.Text = "Ovoid";
            // 
            // circleToolStripMenuItem1
            // 
            this.circleToolStripMenuItem1.Name = "circleToolStripMenuItem1";
            this.circleToolStripMenuItem1.Size = new System.Drawing.Size(106, 22);
            this.circleToolStripMenuItem1.Text = "Circle";
            // 
            // graficToolStripMenuItem
            // 
            this.graficToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.pieToolStripMenuItem,
            this.chartToolStripMenuItem,
            this.histogramToolStripMenuItem});
            this.graficToolStripMenuItem.Name = "graficToolStripMenuItem";
            this.graficToolStripMenuItem.Size = new System.Drawing.Size(169, 22);
            this.graficToolStripMenuItem.Text = "Grafic";
            // 
            // pieToolStripMenuItem
            // 
            this.pieToolStripMenuItem.Name = "pieToolStripMenuItem";
            this.pieToolStripMenuItem.Size = new System.Drawing.Size(130, 22);
            this.pieToolStripMenuItem.Text = "Pie";
            // 
            // chartToolStripMenuItem
            // 
            this.chartToolStripMenuItem.Name = "chartToolStripMenuItem";
            this.chartToolStripMenuItem.Size = new System.Drawing.Size(130, 22);
            this.chartToolStripMenuItem.Text = "Chart";
            // 
            // histogramToolStripMenuItem
            // 
            this.histogramToolStripMenuItem.Name = "histogramToolStripMenuItem";
            this.histogramToolStripMenuItem.Size = new System.Drawing.Size(130, 22);
            this.histogramToolStripMenuItem.Text = "Histogram";
            // 
            // analiticGeometricToolStripMenuItem
            // 
            this.analiticGeometricToolStripMenuItem.Name = "analiticGeometricToolStripMenuItem";
            this.analiticGeometricToolStripMenuItem.Size = new System.Drawing.Size(169, 22);
            this.analiticGeometricToolStripMenuItem.Text = "AnaliticGeometric";
            // 
            // formulasToolStripMenuItem
            // 
            this.formulasToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.trigonometricToolStripMenuItem,
            this.aritmeticToolStripMenuItem,
            this.matematicToolStripMenuItem,
            this.geometricToolStripMenuItem,
            this.analiticToolStripMenuItem});
            this.formulasToolStripMenuItem.Name = "formulasToolStripMenuItem";
            this.formulasToolStripMenuItem.Size = new System.Drawing.Size(68, 20);
            this.formulasToolStripMenuItem.Text = "Formulas";
            // 
            // trigonometricToolStripMenuItem
            // 
            this.trigonometricToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.sinToolStripMenuItem,
            this.cosToolStripMenuItem,
            this.tanToolStripMenuItem,
            this.cotToolStripMenuItem,
            this.secToolStripMenuItem,
            this.cosecToolStripMenuItem});
            this.trigonometricToolStripMenuItem.Name = "trigonometricToolStripMenuItem";
            this.trigonometricToolStripMenuItem.Size = new System.Drawing.Size(148, 22);
            this.trigonometricToolStripMenuItem.Text = "Trigonometric";
            // 
            // sinToolStripMenuItem
            // 
            this.sinToolStripMenuItem.Name = "sinToolStripMenuItem";
            this.sinToolStripMenuItem.Size = new System.Drawing.Size(106, 22);
            this.sinToolStripMenuItem.Text = "Sin";
            // 
            // cosToolStripMenuItem
            // 
            this.cosToolStripMenuItem.Name = "cosToolStripMenuItem";
            this.cosToolStripMenuItem.Size = new System.Drawing.Size(106, 22);
            this.cosToolStripMenuItem.Text = "Cos";
            // 
            // tanToolStripMenuItem
            // 
            this.tanToolStripMenuItem.Name = "tanToolStripMenuItem";
            this.tanToolStripMenuItem.Size = new System.Drawing.Size(106, 22);
            this.tanToolStripMenuItem.Text = "Tan";
            // 
            // cotToolStripMenuItem
            // 
            this.cotToolStripMenuItem.Name = "cotToolStripMenuItem";
            this.cotToolStripMenuItem.Size = new System.Drawing.Size(106, 22);
            this.cotToolStripMenuItem.Text = "Cot";
            // 
            // secToolStripMenuItem
            // 
            this.secToolStripMenuItem.Name = "secToolStripMenuItem";
            this.secToolStripMenuItem.Size = new System.Drawing.Size(106, 22);
            this.secToolStripMenuItem.Text = "Sec";
            // 
            // cosecToolStripMenuItem
            // 
            this.cosecToolStripMenuItem.Name = "cosecToolStripMenuItem";
            this.cosecToolStripMenuItem.Size = new System.Drawing.Size(106, 22);
            this.cosecToolStripMenuItem.Text = "Cosec";
            // 
            // aritmeticToolStripMenuItem
            // 
            this.aritmeticToolStripMenuItem.Name = "aritmeticToolStripMenuItem";
            this.aritmeticToolStripMenuItem.Size = new System.Drawing.Size(148, 22);
            this.aritmeticToolStripMenuItem.Text = "Aritmetic";
            // 
            // matematicToolStripMenuItem
            // 
            this.matematicToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.logToolStripMenuItem,
            this.lnToolStripMenuItem,
            this.expToolStripMenuItem});
            this.matematicToolStripMenuItem.Name = "matematicToolStripMenuItem";
            this.matematicToolStripMenuItem.Size = new System.Drawing.Size(148, 22);
            this.matematicToolStripMenuItem.Text = "Matematic";
            // 
            // logToolStripMenuItem
            // 
            this.logToolStripMenuItem.Name = "logToolStripMenuItem";
            this.logToolStripMenuItem.Size = new System.Drawing.Size(94, 22);
            this.logToolStripMenuItem.Text = "Log";
            // 
            // lnToolStripMenuItem
            // 
            this.lnToolStripMenuItem.Name = "lnToolStripMenuItem";
            this.lnToolStripMenuItem.Size = new System.Drawing.Size(94, 22);
            this.lnToolStripMenuItem.Text = "Ln";
            // 
            // expToolStripMenuItem
            // 
            this.expToolStripMenuItem.Name = "expToolStripMenuItem";
            this.expToolStripMenuItem.Size = new System.Drawing.Size(94, 22);
            this.expToolStripMenuItem.Text = "Exp";
            // 
            // geometricToolStripMenuItem
            // 
            this.geometricToolStripMenuItem.Name = "geometricToolStripMenuItem";
            this.geometricToolStripMenuItem.Size = new System.Drawing.Size(148, 22);
            this.geometricToolStripMenuItem.Text = "Geometric";
            // 
            // analiticToolStripMenuItem
            // 
            this.analiticToolStripMenuItem.Name = "analiticToolStripMenuItem";
            this.analiticToolStripMenuItem.Size = new System.Drawing.Size(148, 22);
            this.analiticToolStripMenuItem.Text = "Analitic";
            // 
            // toolsToolStripMenuItem
            // 
            this.toolsToolStripMenuItem.Name = "toolsToolStripMenuItem";
            this.toolsToolStripMenuItem.Size = new System.Drawing.Size(46, 20);
            this.toolsToolStripMenuItem.Text = "Tools";
            // 
            // optionsToolStripMenuItem
            // 
            this.optionsToolStripMenuItem.Name = "optionsToolStripMenuItem";
            this.optionsToolStripMenuItem.Size = new System.Drawing.Size(61, 20);
            this.optionsToolStripMenuItem.Text = "Options";
            // 
            // windowToolStripMenuItem
            // 
            this.windowToolStripMenuItem.Name = "windowToolStripMenuItem";
            this.windowToolStripMenuItem.Size = new System.Drawing.Size(63, 20);
            this.windowToolStripMenuItem.Text = "Window";
            // 
            // helpToolStripMenuItem
            // 
            this.helpToolStripMenuItem.Name = "helpToolStripMenuItem";
            this.helpToolStripMenuItem.Size = new System.Drawing.Size(44, 20);
            this.helpToolStripMenuItem.Text = "Help";
            // 
            // statusStrip1
            // 
            this.statusStrip1.Location = new System.Drawing.Point(0, 405);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(556, 22);
            this.statusStrip1.TabIndex = 2;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(556, 427);
            this.Controls.Add(this.statusStrip1);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem editToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem viewToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem formatToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem fillToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem shapedToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem basicShape2DToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem dotToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem linesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem lineToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem segmentToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem shapesNGone2DToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem triangleToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem nGonToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem squareToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem pentagonToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem sexagonToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem heptagonToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem octogonToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem decagonToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem dodecagonToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem poligoneToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem poligonToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem pathToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem square2DToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem squareToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem patrulaterToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem paralelogramToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem rombToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem trapezToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem dreptunghiToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem circleToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem cercToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem elipsaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem arcToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ovalToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ovoidToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem graficToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem pieToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem chartToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem histogramToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem analiticGeometricToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem formulasToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem trigonometricToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem sinToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem cosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem tanToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem cotToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem secToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem cosecToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem aritmeticToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem matematicToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem logToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem lnToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem expToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem geometricToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem analiticToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem toolsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem optionsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem windowToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem helpToolStripMenuItem;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripMenuItem circleToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem starToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem startNCornersToolStripMenuItem;
    }
}

